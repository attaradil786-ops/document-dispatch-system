# Running the app locally as http://mis-system.in

This zip is the project with one change already made: `vite.config.ts` now
tells the dev server to accept the hostname `mis-system.in` (Vite blocks
unrecognized hostnames by default as a security measure).

You just need to map that hostname to your own machine and start the server.

## 1. Install dependencies

```bash
npm install
```

## 2. Add environment variables

Copy `.env.example` to `.env.local` and fill in your Supabase project URL/key
(see `src/supabase/schema.sql` and `src/supabase/seed.sql` for the DB setup),
plus your Gemini API key if you use the AI features.

## 3. Point mis-system.in at your machine

Edit your OS hosts file and add this line:

```
127.0.0.1   mis-system.in
```

- **Windows**: edit `C:\Windows\System32\drivers\etc\hosts` as Administrator
  (Notepad run as Admin, or `notepad C:\Windows\System32\drivers\etc\hosts`)
- **macOS / Linux**: `sudo nano /etc/hosts`, add the line, save

No DNS registration or purchase is needed for this — this just makes your
own computer resolve that name to itself. It will only work on the machine
where you edited the hosts file, and only from that machine's browser.

## 4. Run it

```bash
npm run dev
```

Then open **http://mis-system.in:3000** in your browser.

(Vite's dev server doesn't bind to port 80 by default, so the `:3000` stays
in the URL. If you want a bare `http://mis-system.in` with no port, see the
optional step below.)

## 5. (Optional) Drop the port number

To serve on port 80 so the URL is just `http://mis-system.in`, run a
production build behind a local reverse proxy:

```bash
npm run build
npx serve -s dist -l 3000
```

Then use nginx, Caddy, or similar as a reverse proxy from port 80 →
127.0.0.1:3000 (this needs admin/root privileges to bind port 80). Caddy is
the simplest option — a two-line Caddyfile:

```
mis-system.in {
    reverse_proxy localhost:3000
}
```

## Important limitation

This setup only works **on your own computer** — nobody else can reach
`mis-system.in` this way, since the hostname mapping lives in your local
hosts file, not in public DNS. If you eventually want this reachable from
other devices or the internet, that requires actually registering the
`.in` domain with a registrar and deploying to a public host (Vercel,
Netlify, a VPS, etc.) — happy to walk through that whenever you're ready.
